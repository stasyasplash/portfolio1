# Портфолио

A Pen created on CodePen.

Original URL: [https://codepen.io/Stasya-Splash/pen/zxKjQRz](https://codepen.io/Stasya-Splash/pen/zxKjQRz).

